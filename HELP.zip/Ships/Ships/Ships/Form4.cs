﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ships
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

      private void Form4_Load(object sender, EventArgs e)
        {
            StreamReader f = new StreamReader("1.txt");
            string s = f.ReadLine();
            f.Close();
            if (s=="Бухгалтер")
            {
                button1.Enabled = false;
                button2.Enabled = true;
            }    
        }
    }
}
