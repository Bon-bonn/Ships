﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ships
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamWriter f = new StreamWriter("1.txt", false);
            f.WriteLine(comboBox1.Text);
            f.Close();
            if ((comboBox1.Text == "Владелец-продавец или Заместитель владельца") && (textBox1.Text == "111"))
            {
                MessageBox.Show("Добро пожаловать, Владелец или Заместитель!");
                Form5 form5 = new Form5();
                form5.Show();
            }
            else
            if ((comboBox1.Text == "Администратор") && (textBox1.Text == "222"))
            {
                MessageBox.Show("Добро пожаловать, Администратор!");
                Form5 form5 = new Form5();
                form5.Show();
            }
            else
            if ((comboBox1.Text == "Бухгалтер") && (textBox1.Text == "333"))
            {
                MessageBox.Show("Добро пожаловать, Бухгалтер!");
                Form5 form5 = new Form5();
                form5.Show();
            }
            else
                MessageBox.Show("Ошибка ввода логина или пароля");
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    } 
}

  
