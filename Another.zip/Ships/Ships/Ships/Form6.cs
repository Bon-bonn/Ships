﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Ships
{
    public partial class Form6 : Form
    {
        public static string connectString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source = Судна.mdb";
        private OleDbConnection SomeConnection;
        public Form6()
        {
            InitializeComponent();
            SomeConnection = new OleDbConnection(connectString);
            SomeConnection.Open();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "суднаDataSet.Сотрудники". При необходимости она может быть перемещена или удалена.
            this.сотрудникиTableAdapter.Fill(this.суднаDataSet.Сотрудники);

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
          
    }

        private void Form6_FormClosing(object sender, FormClosingEventArgs e)
        {
            SomeConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int codeempl = Convert.ToInt32(textBox13.Text);
            string query = "DELETE FROM Сотрудники WHERE [ID_Сотрудника] = " + codeempl;
            OleDbCommand command = new OleDbCommand(query, SomeConnection);
            command.ExecuteNonQuery();
            MessageBox.Show("Данные о сотруднике удалены");
            this.сотрудникиTableAdapter.Fill(this.суднаDataSet.Сотрудники);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int codeempl = Convert.ToInt32(textBox14.Text);
            string query = "UPDATE Сотрудники SET Должность = '" + textBox15.Text+ "' WHERE [ID_Сотрудника] = " + codeempl;
            OleDbCommand command = new OleDbCommand(query, SomeConnection);
            command.ExecuteNonQuery();
            MessageBox.Show("Должность сотрудника обновлена");
            this.сотрудникиTableAdapter.Fill(this.суднаDataSet.Сотрудники);
        }
    }
}
